def zip_funcion():
    return ("Este es un módulo comprimido en zip.")